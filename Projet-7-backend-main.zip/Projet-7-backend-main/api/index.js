import server from "../src/server";

export default server